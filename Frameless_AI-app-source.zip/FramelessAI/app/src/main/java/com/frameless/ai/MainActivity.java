package com.frameless.ai;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Hosts the Frameless_AI WebUI (assets/index.html) and gives it the same "ksu.exec" bridge the
 * KernelSU WebUI has, running commands through su. The in-game panel service lives in this same app.
 */
public class MainActivity extends Activity {
    static final String ENGINE = "/data/adb/modules/frameless_ai/bin/frameless.sh";
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#05030B"));
        w.setNavigationBarColor(Color.parseColor("#05030B"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#05030B"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(), "ksu");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("file:///android_asset/")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        checkModule();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void checkModule() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Result id = su("id");
                if (id.code != 0) {
                    toast("Root access is needed. Allow Frameless_AI in your root manager.");
                    return;
                }
                if (su("[ -f " + ENGINE + " ]").code != 0) {
                    toast("Frameless_AI module not found. Flash the module and reboot.");
                }
            }
        }).start();
    }

    // ------------------------------------------------------------------ su helper

    private static class Result {
        int code = 1;
        String out = "";
        String err = "";
    }

    private static String drain(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private static Result su(String cmd) {
        final Result r = new Result();
        try {
            final Process p = new ProcessBuilder("su", "-c", cmd).start();
            p.getOutputStream().close();
            Thread te = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        r.err = drain(p.getErrorStream());
                    } catch (Exception ignored) {
                    }
                }
            });
            te.start();
            r.out = drain(p.getInputStream());
            r.code = p.waitFor();
            te.join(2000);
        } catch (Exception e) {
            r.err = String.valueOf(e);
        }
        return r;
    }

    // ------------------------------------------------------------------ ksu.exec(cmd, options, callbackName)

    private class Bridge {
        @JavascriptInterface
        public void exec(final String cmd, String options, final String cb) {
            if (cb == null || !cb.matches("[A-Za-z0-9_]+")) return;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final Result r = su(cmd);
                    final String js = "window['" + cb + "'](" + r.code + "," + JSONObject.quote(r.out) + ","
                            + JSONObject.quote(r.err) + ")";
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web != null) web.evaluateJavascript(js, null);
                        }
                    });
                }
            }).start();
        }
    }
}
